<?php
include('conn.php');
session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get username and password from the form
    $Id = $_POST['Id'];
    $Name = $_POST['Name'];
    $Password = $_POST['password'];

    // Check in the Customer table
    $EmployeeQuery = "SELECT * FROM DeliveryPersonInfos WHERE Pid = ?";
    $EmployeeStmt = $conn->prepare($EmployeeQuery);
    $EmployeeStmt->bind_param("i", $Id);
    $EmployeeStmt->execute();
    $EmployeeResult = $EmployeeStmt->get_result();

    // ...

    if ($EmployeeResult->num_rows > 0) {
        $EmployeeRow = $EmployeeResult->fetch_assoc();
        $PasswordFromDatabase = $EmployeeRow['Pass_word'];
        $NameFromDatabase = $EmployeeRow['PName'];

        
        // Check if entered password matches the one stored in the database
        if ($Password === $PasswordFromDatabase && $Name == $NameFromDatabase) {
            $_SESSION['Employee_id'] = $EmployeeRow['Pid'];

            header('Location: DeliveryDashboard.php');
            exit();
        }
        else {
            // Failed login, redirect back to the login page with an error message
            header('Location: index.php?error=true');
            exit();
        }
    } else {
        // Failed login, redirect back to the login page with an error message
        header('Location: index.php?error=true');
        exit();
    }
    // ...
} else {
    // Redirect back to the login page if the form was not submitted
    header('Location: index.php');
    exit();
}
