<?php 

    $host = "localhost";
    $username = "root";
    $password = "root";
    $database = "DeliverySystem";

    $conn = new mysqli($host , $username , $password, $database);

    if($conn->connect_error){
        echo 'Connection Failed';
    }

?>