<!-- ViewCart.php -->
<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['user_id'])) {
    $user_id_url = $_GET['user_id'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: hsla(180, 2%, 8%, 1);
            color:white;
            margin-bottom:100px;
        }

        .container {
            width: 100%;
            margin: auto;
            padding: 20px;
        }

        table {
            width: 1350px;
            border-collapse: collapse;
            margin-top: 20px;
            margin-left:30px;
        }

        table, th, td {
            border: 1px solid hsl(38, 61%, 73%);
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            color : hsl(38, 61%, 73%);
        }

        button {
            padding: 10px;
            background-color: hsl(38, 61%, 73%);
            color: black;
            margin-left:665px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            opacity:0.7;
        }
        .Home{
            text-align:center;
            margin-top:15px;
        }
        .href{
            color:white;
            text-decoration:none;
        }

        .href:hover{
            text-decoration:underline;
            color:gray;
        }

    </style>
</head>

<body>
    <div class="container">
        <?php
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart']) && $user_id_url == $user_id) {
            echo '<table>';
            echo '<tr><th>Name</th><th>Price</th></tr>';
            foreach ($_SESSION['cart'] as $item) {
                echo "<tr><td>{$item['MName']}</td><td>{$item['Price']} dh</td></tr>";
            }
            echo '</table>';
        } else {
            echo "<p>Your shopping cart is empty.</p>";
        }
        ?>
    </div>
    <div>
        <form method="post" action="Payment.php">
            <button type="submit">Proceed to Payment</button>
        </form>
    </div>
    <div class="Home"><a class="href" href = "UserDashboard.php">Back Home</a></div>
</body>

</html>
