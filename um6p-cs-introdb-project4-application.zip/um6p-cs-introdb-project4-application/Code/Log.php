<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
       
    body {
        margin: 0;
        padding: 0;
        font-family: 'Arial', sans-serif;
        background: linear-gradient(to bottom, hsl(0, 0%, 0%), #222222);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .login-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .login-form {
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 300px;
    }

    h2 {
        text-align: center;
        color: WHITE;
    }

    .form-group {
        margin-bottom: 15px;
    }

    label {
        display: block;
        margin-bottom: 8px;
        color: #555;
    }

    input {
        background-color: hsl(180, 2%, 20%); 
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    button {
        width: 100%;
        padding: 12px;
        background-color: white;
        color: black;
        border: none;
        margin-top:15px;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        opacity:0.4;
    }

    .error-message {
        color: red;
        margin-bottom: 15px;
        text-align: center;
    }
</style>

    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <h2>Welcome !</h2>
            <form action="Login.php" method="post">
                <div class="form-group">
                    <label for="Email">Email:</label>
                    <input type="text" name="Email" placeholder="Email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" placeholder="Password" required>
                </div>

                <button type="submit">Login</button>
            </form>
        </div>
    </div>
</body>
</html>