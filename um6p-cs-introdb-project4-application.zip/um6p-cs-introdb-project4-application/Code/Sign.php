<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-image: url(SignBack.jpg);
        display: flex;
        background: linear-gradient(to bottom, hsl(0, 0%, 0%), #222222);
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    form {
        padding: 17px;
        width: 300px;
        border-radius: 8px;
        margin-top:-5px;
    }

    h2 {
        text-align: center;
        color: #333;
    }

    label {
        display: block;
        margin: 10px 0 5px;
        color: #555;
    }

    input {
        width: 100%;
        background-color: hsl(180, 2%, 20%); 
        padding: 8px;
        margin-bottom: 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        margin-top:15px;
        background-color: white;
        color: black;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }

    button:hover {
        opacity: 0.5;
    }

    </style>
    <title>Sign Up</title>
</head>

<body>
    <form action="SignUp.php" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" placeholder="Username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" placeholder="Password" required>

        <label for="email">Email:</label>
        <input type="email" name="email" placeholder="Email" required>

        <label for="address">Address:</label>
        <input type="text" name="address" placeholder="Address" required>

        <label for="phone_number">Phone Number:</label> 
        <input type="text" name="phone_number" placeholder="Phone Number" required>

        <button type="submit">Sign Up</button>
    </form>
</body>

</html>
