<?php
include('conn.php'); 

$query = "SELECT
            Customer.Cid AS CustomerID,
            Customer.CName AS CustomerName,
            Orders.Order_id AS OrderID,
            Orders.Order_city AS OrderCity,
            Vehicle.Vid AS VehicleID,
            Payment_online.PTime AS PaymentTime
          FROM Customer
          JOIN Orders ON Customer.Cid = Orders.Cid
          JOIN Delivery ON Orders.Order_id = Delivery.Did
          JOIN Vehicle ON Delivery.Vid = Vehicle.Vid
          JOIN Pays ON Orders.Order_id = Pays.Order_id
          JOIN Payment_online ON Pays.PYid = Payment_online.PYid
          ORDER BY Payment_online.PTime DESC ";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: hsla(180, 2%, 8%, 1);
            color: white;
            margin-bottom: 100px;
        }
        table{
            text-align: center;
            width:1400px;
            margin-right:auto;
            margin-left:auto;
            width: 70%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        table, th, td {
            border: 1px solid hsl(38, 61%, 73%);
        }
        th, td {
            padding: 15px;
        }
        h1{
            text-align:center;
        }
        .LogOut{
            position:absolute;
            margin-top:2px;
            border: 1px solid black;
            padding:10px;
            border-radius:6px;
            background-color:black;
            margin-left:10px;
        }
        .LogOut:hover{
            opacity:0.4;
            cursor: pointer;
        }
        .href{
            text-decoration:none;
            color: white;
        }
    </style>
</head>

<body>
    <div class="LogOut"><a class="href" href = "DeliveryLogOut.php">Log Out</a></div>
    <h1>Order Informations</h1>
    <div>
    <table>
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Customer Name</th>
                <th>Order ID</th>
                <th>Order City</th>
                <th>Vehicle ID</th>
                <th>Payment Time</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['CustomerID'] . "</td>";
                    echo "<td>" . $row['CustomerName'] . "</td>";
                    echo "<td>" . $row['OrderID'] . "</td>";
                    echo "<td>" . $row['OrderCity'] . "</td>";
                    echo "<td>" . $row['VehicleID'] . "</td>";
                    echo "<td>" . $row['PaymentTime'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No data available</td></tr>";
            }
            ?>
        </tbody>
    </table>
    </div>


</body>

</html>

<?php
    $conn->close();
?>