<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Restaurant</title>
    <style>
        body{
            background-color:hsla(210, 4%, 11%, 1);
            margin-top:50px;
            position: relative;
        }
        div{
            color: white;
            font-family: Arial Roboto;
        }
        .header div{
            text-align: center;
        }
        .top{
            color:hsl(38, 61%, 73%);
            font-size: 18px;
            margin-top:15px;
            font-family: Arial;
        }
        .under-top{
            font-size: 34px;
        }
        .grid {
            display: grid;
            grid-template-columns: 280px 280px 280px;
            gap: 0 100px; 
            margin-top: 50px;
            margin-left: 210px;
        }

        .inner-grid{
            margin-bottom:50px;
            background-color: hsla(180, 2%, 8%, 1);
            height: 250px;
        }

        .inner-grid img {
            height: 100px;
            width: 100px;
            margin-left: 90px;
            margin-top: 30px;
            border-radius: 13px;
        }

        .inner-grid img:hover{
            opacity: 0.8;
            cursor: pointer;
            transform: scale(1.1); 
            transition: transform 0.2s ;
        }

        .meal{
            text-align: center;
            margin-top:8px;
            font-size:25px;
        }

        .meal:hover{
            cursor: pointer;
            color:hsl(38, 61%, 73%);
            transition-duration: 0.2s;
        }

        .infos{
            text-align: center;
        }
        .dec-image {
              position: absolute;
              margin-top: -200px;
              margin-left:100px;
        }
        .dec-image img{
              height: 200px;
              width: 200px;
        }
        .dec-image1 img{
            height: 140px;
            width: 150px;
            position: absolute;
            margin-top: 470px;
            margin-left:40px;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #fff;
            background-color: rgba(0,0,0,.1);
            padding: 30px;
            margin-top:-10px;
        }
        .button {
            cursor: pointer;
            display: inline;
            background-color: black;
            border: 1 solid black;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .button:hover {
            opacity: 0.4;
        }
        .on-hover {
            margin: 0 15px;
            cursor: pointer;
            margin-left:90px;
            display: inline; 
        }
        .on-hover:hover {
            text-decoration: underline;
            opacity: 0.5;
        }
        .ByteBite {
            font-size: 24px;
            font-weight: bold;
        }
        .ByteBite:hover{
            cursor: pointer;
        }
        .Login{
            color: white;
            text-decoration: none;
        }
        .details{
            cursor: pointer;
            background-color: black;
            border: none;
            color:white;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
        }

        .details-div{
            cursor: pointer;
            display: inline;
            transition: background-color 0.3s;
        }
        .details-div:hover{
            opacity: 0.4;
        }
        
    </style>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
</head>

<body>
    <div>
        <div class="top-bar">
                <div>
                    <div class="ByteBite">ByteBite</div>
                </div>
                <div>
                    <div class="on-hover">Home</div>
                    
                </div>
                <div>
                    <div class="button"><a class="Login" href="LogOut.php">Log Out</a></div>
                    <form  class="details-div" action="UserDetails.php" method="post">
                        <button class="details" type="submit">Details</button>
                    </form>
                </div>
            </div>
    </div>
    <div class="dec-image1"><img src="/images/shape-8.png"></div>
    <div class="dec-image"><img src="/images/shape-7.png"></div>
    <div class="header">
        <div class="top">Special Selection</div>
        <br>
        <br>
        <div class="under-top">Our Restaurants</div>
    </div>
    <br>

    <div class="grid">
    <?php
        include ('conn.php');
        $sql = "SELECT * FROM Restaurant LIMIT 21";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="inner-grid">
                    <div><a href="Menu.php?restaurant_id= <?php echo $row['Rid'];?>"><img src="/images/badge-2-bg.png"></a></div>
                    <div>
                        <div class="little-flex">
                            <div class="meal"><?php echo $row['RName']; ?></div>
                        </div>
                        <br>
                        <div class="infos"><?php echo $row['RCity']; ?></div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "0 results";
        }

        $conn->close();
        ?>  
    </div>
</body>

    
</html>