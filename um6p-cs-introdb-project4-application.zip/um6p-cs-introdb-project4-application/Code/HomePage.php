<!DOCTYPE html>
<html>
    <head>
        <title>ByteBite</title>
        <link rel="stylesheet" href="HomePage.css" >
    </head>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url(/images/hero-slider-1.jpg);
            background-size: 100%;
            
        }

        div{
            color: #fafafa;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #fff;
            padding: 30px;
        }

        .ByteBite {
            font-size: 24px;
            font-weight: bold;
        }
        .ByteBite:hover{
            cursor: pointer;
        }

        .on-hover {
            margin: 0 15px;
            cursor: pointer;
            display: inline; 
        }

        .on-hover-mail{
            color: white;
            text-decoration: none;
        }

        .on-hover:hover {
            text-decoration: underline;
            opacity: 0.5;
        }

        .button {
            cursor: pointer;
            display: inline;
            background-color: #211e1e;
            border: 1 solid rgb(255, 2, 2);
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .button:hover {
            opacity: 0.4;
        }
        .center {
            margin-top: 150px;
            margin-left: 250px;
        }

        .Slogan {
            font-size: 50px;
            width: 600px;
            font-weight: bold;
        }
        .under-slogan{
            font-size: 15px;
        }

        .search-container {
            display: flex;
            max-width: 350px;
        }

        .search-input {
            margin-top: 10px;
            margin-left: -5px;
            border-radius: 200px;
            border: none;
            flex: 1;
            padding: 10px;
        }

        .search-button {
            background-color: black;
            border:none;
            color: #ffffff;
            padding: 10px 15px;
            border-radius: 30px;
            cursor: pointer;
            margin-top: 10px;
            margin-left: -71px;
        }

        .search-button:hover {
            opacity: 0.9;
            transition-duration: 0.2s;
        }

        .SignUp, .Login{
            color: white;
            text-decoration: none;
        }
    </style>
    <body>
        <div class="first-body">
            <div class="top-bar">
                <div>
                    <div class="ByteBite">ByteBite</div>
                </div>
                <div>
                    <div class="on-hover">Home</div>
                    <div class="on-hover"><a class="on-hover-mail" href="mailto:jaafar.yeffou@um6p.ma">Contact us</a></div>
                </div>
                <div>
                    <div class="button"><a class="SignUp" href="Sign.php">Sign Up</a></div>
                    <div class="button"><a class="Login" href="Role.php">Log In</a></div>
                </div>
            </div>
            <div class="center">
                <div class="Slogan">Your Taste, Our Mission Bringing Joy to Every Bite.</div>
                <div class="under-slogan">Get It Delivered Right To Your Door.</div>
                
            </div>
            
        </div>
    
    </body>
</html>