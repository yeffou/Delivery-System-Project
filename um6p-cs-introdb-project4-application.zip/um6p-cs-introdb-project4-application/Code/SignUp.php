<?php
include('conn.php'); // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Calculate the next customer ID
    $result = mysqli_query($conn, "SELECT MAX(Cid) AS max_cid FROM DeliverySystem.Customer");
    $row = mysqli_fetch_assoc($result);
    $nextCID = ($row['max_cid'] === null) ? 1 : $row['max_cid'] + 1;

    $username = $_POST['username'];
    $password = $_POST['password']; // Hash the password
    $email = $_POST['email'];
    $address = $_POST['address']; // New field
    $phone_number = $_POST['phone_number']; // New field

    // Insert the new customer into the database
    $sql = "INSERT INTO DeliverySystem.Customer (Cid, Cname, Adress, Email, Pass_word, Phone_Number) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $nextCID, $username, $address, $email, $password, $phone_number);

    if ($stmt->execute()) {
        // Registration successful, you can redirect to a welcome page
        header('Location: Log.php');
        exit();
    } else {
        // Registration failed
        echo 'Registration failed. Please try again.';
    }

    $stmt->close();
    mysqli_close($conn);
}
?>

