<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$totalPrice = 0;
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $totalPrice += $item['Price'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: hsla(180, 2%, 8%, 1);
    color: white; 
}

header {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 1em 0;
}

nav {
    background-color: #444;
    padding: 0.5em;
}

nav ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

nav ul li {
    display: inline;
    margin-right: 1em;
}

nav a {
    text-decoration: none;
    color: #fff;
}

main {
    max-width: 600px;
    margin: 2em auto;
    padding: 1em;
    background-color: hsla(180, 2%, 8%, 1);
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

form {
    display: grid;
    gap: 1em;
}

label {
    display: block;
    font-weight: bold;
    color: #fff; 
}

input {
    width: 100%;
    padding: 0.5em;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: hsl(180, 2%, 20%); 
    color: #fff; 
}

.name-fields {
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    gap: 1em;
}

.name-fields label {
    font-weight: bold;
    color: #fff; 
}

.name-fields input {
    width: 100%;
    padding: 0.5em;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: hsl(180, 2%, 20%);
    color: #fff;
}

.button-container {
    display: flex;
    justify-content: space-between;
    margin-top: 1em;
}

button {
    padding: 0.5em 1em;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    width: 290px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

#pay-button {
    background-color: Black;
    color: #fff;
}

#cancel-button {
    background-color: White;
    color: black;
}
#pay-button:hover{
    opacity:0.4;
}
#cancel-button:hover{
    opacity:0.4;
}
.Home{
    text-decoration:none;
    color:white;
}
.Home:hover{
    cursor: pointer;
    color :hsl(38, 61%, 73%);
    text-decoration:underline;
}
h2{
    color :hsl(38, 61%, 73%);
}

    </style>
    <script>
    function validateCreditCard() {
        // Add your credit card validation logic here if needed
        return true;
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Select the payment form
        const paymentForm = document.querySelector('form');

        // Add a submit event listener to the form
        paymentForm.addEventListener('submit', function (event) {
            // Prevent the default form submission behavior
            event.preventDefault();

            // Perform a simulated successful payment
            alert('Payment successful!'); // You can replace this with your actual payment processing logic

        });
    });
    </script>
    <title>Payment - ByteBite Delivery Engine</title>
</head>

<body>
  

    <div>
        <ul>
            <li><a class="Home" href="UserDashboard.php">Home</a></li>
        </ul>
    </div>

    <main>
        <h2>Payment Details</h2>

        <p>Total Price: <?php echo number_format($totalPrice, 2) . ' dh'; ?></p>

        <form onsubmit="return validateCreditCard()" action="OrderConfirmation.php" method="post">
            <div class="name-fields">
                <label for="first_name">First Name:</label>
                <input type="text" id="first_name" name="first_name" required>

                <label for="last_name">Last Name:</label>
                <input type="text" id="last_name" name="last_name" required>
            </div>

            <label for="card_number">Card Number:</label>
            <input type="text" id="card_number" name="card_number" required>

            <label for="expiry_date">Expiration Date:</label>
            <input type="text" id="expiry_date" name="expiry_date" required>

            <label for="cvv">Security Code:</label>
            <input type="text" id="Code" name="cvv" required>

            <div class="button-container">
                <button id="cancel-button" type="button">Cancel</button>
                <button id="pay-button" type="submit">Pay</button>
            </div>
        </form>
    </main>

</body>

</html>
