<?php
include('conn.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not logged in
    header('Location: HomePage.php');
    exit();
}

// Get user information from the database
$user_id = $_SESSION['user_id'];
$userQuery = "SELECT * FROM Customer WHERE Cid = ?";
$userStmt = $conn->prepare($userQuery);
$userStmt->bind_param("i", $user_id);
$userStmt->execute();
$userResult = $userStmt->get_result();

if ($userResult->num_rows > 0) {
    $userRow = $userResult->fetch_assoc();
    $userName = $userRow['CName'];
    $userEmail = $userRow['Email'];
    $userPhoneNumber = $userRow['Phone_Number'];
    // Add other user information if needed
} else {
    header('Location: HomePage.php');
    exit();
}

// Get orders information from the database (including details from OrderDetailsTable and Restaurant)
$orderQuery = "SELECT Orders.Order_id, Contains.MName, Contains.Rid, Restaurant.RName
               FROM Orders
               LEFT JOIN Contains ON Orders.Order_id = Contains.Order_id
               LEFT JOIN Restaurant ON Contains.Rid = Restaurant.Rid
               WHERE Orders.Cid = ?";
    $orderStmt = $conn->prepare($orderQuery);
    $orderStmt->bind_param("i", $user_id);
    $orderStmt->execute();
    $orderResult = $orderStmt->get_result();
    ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: hsla(180, 2%, 8%, 1);
            color: white;
            margin-bottom: 100px;
        }

        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            text-align: center;
        }

        table {
            width: 70%;
            border-collapse: collapse;
            margin: 20px auto;
        }

        table, th, td {
            border: 1px solid hsl(38, 61%, 73%);
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            color: hsl(38, 61%, 73%);
        }

        hr {
            border: 1px solid hsl(38, 61%, 73%);
            margin: 20px 0;
        }

        a {
            color: #87CEEB;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>User Details</h1>
        <table>
            <tr>
                <th>User ID</th>
                <td><?php echo $user_id; ?></td>
            </tr>
            <tr>
                <th>Name</th>
                <td><?php echo $userName; ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo $userEmail; ?></td>
            </tr>
            <tr>
                <th>Phone Number</th>
                <td><?php echo $userPhoneNumber; ?></td>
            </tr>
        </table>

        <h2>Orders</h2>
        <?php
        if ($orderResult->num_rows > 0) {
            echo '<table>';
            echo '<tr><th>Order ID</th><th>Menu Item Name</th><th>Restaurant Name</th></tr>';
            while ($orderRow = $orderResult->fetch_assoc()) {
                echo "<tr><td>" . $orderRow['Order_id'] . "</td>";
                echo "<td>" . $orderRow['MName'] . "</td>";
                echo "<td>" . $orderRow['RName'] . "</td></tr>";
            }
            echo '</table>';
        } else {
            echo "<p>No orders found.</p>";
        }
        ?>

        <a href="UserDashboard.php">Back to Restaurants</a>
    </div>
</body>

</html>
