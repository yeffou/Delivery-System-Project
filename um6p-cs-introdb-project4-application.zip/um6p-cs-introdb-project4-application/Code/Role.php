<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Roles</title>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: hsla(210, 4%, 11%, 1);
            display: grid;
            grid-template-columns: 400px 400px;
            gap: 200px;
            margin-top:80px;
            margin-left:200px;
        }

        .customer img{
            height:100%;
            width:100%;
        }
        .livreur img{
            height:100%;
            width:100%;
        }
        .livreur img:hover{
            cursor: pointer;
            transform: scale(1.1); 
            transition: transform 0.2s ;
        }
        .customer img:hover{
            cursor: pointer;
            transform: scale(1.1); 
            transition: transform 0.2s ;
        }
        .customer div{
            text-align: center;
            color: white;
            font-size:25px;
            font-familly:monospace;

        }
        .livreur div{
            text-align: center;
            color: white;
            font-size:25px;
        }

    </style>
</head>
<body>
    <div class="customer">
        <a href="Log.php"><img src="/images/Customer.png"></a>
        <br>
        <br>
        <div>Customer</div>
    </div>
    <div class="livreur">
        <a href="DeliveryLog.php"><img src="/images/DeliveryPerson.png"></a>
        <br>
        <br>
        <div>Employee</div>
    </div>
</body>
</html>
