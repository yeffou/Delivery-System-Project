<?php
session_start(); 

include('conn.php');

$selectedRestaurantID = isset($_GET['restaurant_id']) ? $_GET['restaurant_id'] : null;

if ($selectedRestaurantID !== null) {
    $restaurantQuery = "SELECT * FROM Restaurant WHERE Rid = $selectedRestaurantID";
    $restaurantResult = $conn->query($restaurantQuery);
    $restaurant = $restaurantResult->fetch_assoc();

    // Fetch the menu items for the selected restaurant
    $menuQuery = "SELECT * FROM Meal WHERE Rid = $selectedRestaurantID LIMIT 20";
    $menuResult = $conn->query($menuQuery);
}

// Handle adding a meal to the cart
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart'])) {
        $selectedMeal = $_POST['meal'];

        // Fetch the details of the selected meal
        $mealDetailsQuery = "SELECT * FROM Meal WHERE MName = '$selectedMeal' AND Rid = $selectedRestaurantID";
        $mealDetailsResult = $conn->query($mealDetailsQuery);

        if ($mealDetailsResult->num_rows > 0) {
            $mealDetails = $mealDetailsResult->fetch_assoc();

            // Store the selected meal in the session
            $_SESSION['cart'][] = [
                'user_id' => $_SESSION['user_id'],
                'MName' => $mealDetails['MName'],
                'Price' => $mealDetails['Price'],
            ];
        }
    }

    // Handle removing a meal from the cart
    if (isset($_POST['remove_from_cart'])) {
        $selectedMeal = $_POST['meal'];

        // Find the index of the item in the cart
        $index = array_search($selectedMeal, array_column($_SESSION['cart'], 'MName'));

        // Remove the item from the cart
        if ($index !== false) {
            unset($_SESSION['cart'][$index]);
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex the array
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place an Order - ByteBite Delivery Engine</title>
    <style>
        body {
            background-color: hsla(210, 4%, 11%, 1);
            margin-top: 50px;
            margin-bottom: 70px;
        }

        div {
            color: white;
            font-family: Arial Roboto;
        }

        .header div {
            text-align: center;
        }

        .top {
            color: hsl(38, 61%, 73%);
            font-size: 18px;
            margin-top: 15px;
            font-family: Arial;
        }

        .under-top {
            font-size: 34px;
        }

        .grid {
            display: grid;
            grid-template-columns: 200px 200px;
            gap: 0 500px;
            margin-top: 50px;
            margin-left: 170px;
            position: relative;

        }

        .inner-grid {
            display: grid;
            grid-template-columns: 80px 300px;
            gap: 25px;
            margin-top: 70px;
        }

        .inner-grid img {
            max-width: 100%;
            height: auto;
            border-radius: 13px;
        }

        .inner-grid img:hover {
            opacity: 0.8;
            transform: scale(1.1);
            transition: transform 0.2s;
        }

        .little-flex {
            display: flex;
            justify-content: space-between;
        }

        .grid::after {
            content: '';
            position: absolute;
            top: 20px;
            left: 44%;
            height: 100%;
            width: 1px;
            background-color: gainsboro;
            transform: translateX(-50%);
        }

        .infos {
            color: rgb(168, 165, 165);
        }

        .price {
            color: hsl(38, 61%, 73%);
        }

        .meal:hover {
            cursor: pointer;
            color: hsl(38, 61%, 73%);
            transition-duration: 0.2s;
        }

        .timing {
            margin-top: 80px;
            text-align: center;
            font-family: Arial;
        }

        .time {
            color: hsl(38, 61%, 73%);
        }

        .dec-image {
            position: absolute;
            margin-top: -310px;
            margin-left: 1050px;
        }

        .dec-image img {
            height: 300px;
            width: 300px;
        }

        .moving-image {
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('shape-2.png') no repeat;
            Z-index: -1;
        }
        .shopping-image{
            margin-left:40px;
            position:absolute;
            margin-top:20px;
            display: inline;
        }
        .shopping-image:hover{
            cursor: pointer;
            opacity:0.6;
        }
        .on-hover {
            margin: 0 15px;
            cursor: pointer;
            margin-right:40px;
            display: inline; 
            color: white;
            text-decoration: none;
        }
        .on-hover:hover {
            text-decoration: underline;
            color : hsl(38, 61%, 73%);
        }
        .ByteBite {
            font-size: 24px;
            font-weight: bold;
            display: inline; 
        }
        .ByteBite:hover{
            cursor: pointer;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #fff;
            background-color: rgba(0,0,0,.1);
            padding: 30px;
            margin-top:-10px;
        }
        .Login{
            color: white;
            text-decoration: none;
        }
        .Login:hover{
            color:hsl(38, 61%, 73%);
            cursor: pointer;
        }
        .Buy{
            background-color:hsl(38, 61%, 73%);
            color:Black;
            font-size:12px;
            padding:11px;
            border-radius:100px;
            border :none;
        }
    

    </style>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
</head>

<body>
        <div class="top-bar">
                <div>
                    <div class="ByteBite">ByteBite</div>
                </div>
                <div>
                    <div><a class="on-hover" href="UserDashboard.php">Home</a></div>
                    
                </div>
                <div>
                    <div class="button"><a class="Login" href="LogOut.php">Log Out</a></div>
                </div>
            </div>
        </div>
        <div class="shopping-image">
            <a href="ViewCart.php?user_id=<?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : ''; ?>"><img src="/images/ShoppingCard.png"></a>
        </div>
    
    <div class="moving-image">
        <img src="/images/shape-5.png">
    </div>
    <div class="dec-image">
        <img src="/images/shape-9.png">
    </div>
    <div class="header">
        <div class="top">Special Selection</div>
        <br>
        <div><img src="/images/badge-1.png"></div>
        <br>
        <div class="under-top">Delicious Menu</div>
    </div>

    <div class="grid">
        <?php
        if ($menuResult->num_rows > 0) {
            while ($row = $menuResult->fetch_assoc()) {
                ?>
                <div class="inner-grid">
                    <div><img src="/images/cutlery.png"></div>
                <div>
                        <div class="little-flex">
                            <div class="meal"><?php echo $row['MName']; ?></div>
                            <div class="price"><?php echo $row['Price'].'dh'; ?></div>
                        </div>
                        <br>
                        <form method="post" action="">
                                <input type="hidden" name="meal" value="<?php echo $row['MName']; ?>">
                                <div class="Buy-div"><button class="Buy" type="submit" name="add_to_cart">Add to Cart</button></div>
                        </form>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "0 results";
        }
        ?>  
    </div>

    

</body>

</html>