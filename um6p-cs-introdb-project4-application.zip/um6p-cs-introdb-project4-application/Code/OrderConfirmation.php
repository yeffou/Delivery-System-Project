<?php
include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $cardNumber = $_POST['card_number'];
    $expiryDate = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];
    session_start();
    $userId = $_SESSION['user_id'];
    $restaurantId = $_POST['restaurant_id'];
    $meal = $_POST['meal'];
   
    $getMaxPyIdSql = "SELECT MAX(PYid) AS max_py_id FROM Payment";
    $result = mysqli_query($conn, $getMaxPyIdSql);
    $row = mysqli_fetch_assoc($result);
    $maxPyId = $row['max_py_id'];

    // Increment Py_id for the new payment
    $paymentId = $maxPyId + 1;

    // Insert into the Payment table
    $insertPaymentSql = "INSERT INTO Payment_online (PYid, PDate) VALUES ('$paymentId', CURDATE())";
    mysqli_query($conn, $insertPaymentSql);

    // Get the current maximum Order_id from the Orders table
    $getMaxOrderIdSql = "SELECT MAX(Order_id) AS max_order_id FROM Orders";
    $result = mysqli_query($conn, $getMaxOrderIdSql);
    $row = mysqli_fetch_assoc($result);
    $maxOrderId = $row['max_order_id'];

    // Increment Order_id for the new order
    $orderId = $maxOrderId + 1;

    // Insert into the Orders table
    $insertOrderSql = "INSERT INTO Orders (Order_id, Cid, Order_city) VALUES ('$orderId', '$userId',  (SELECT RCity FROM Restaurants WHERE Rid = '$restaurantId'))"; // Adjust Cid and Order_city as needed
    mysqli_query($conn, $insertOrderSql);
    $sqlContains = "INSERT INTO Contains (Order_id, Rid, MName) VALUES ('$orderId', '$restaurantId', '$meal')";


    // Insert into the Pays table
    $insertPaysSql = "INSERT INTO Pays (Order_id, Pyid) VALUES ('$orderId', '$paymentId')";
    mysqli_query($conn, $insertPaysSql);

    // Move the echo after the header call
    header("Location: OrderStatus.php?order_id=$orderId&status=validate_order");
    echo "Order placed successfully!";
    exit();
} else {
    // If the form is not submitted, redirect to the home page or handle it accordingly
    header("Location: home.php");
    exit();
}

mysqli_close($conn);
?>