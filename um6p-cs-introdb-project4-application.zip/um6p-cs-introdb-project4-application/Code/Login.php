<?php
include('conn.php');
session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get username and password from the form
    $Email = $_POST['Email'];
    $enteredPassword = $_POST['password'];

    // Check in the Customer table
    $customerQuery = "SELECT * FROM Customer WHERE Email = ?";
    $customerStmt = $conn->prepare($customerQuery);
    $customerStmt->bind_param("s", $Email);
    $customerStmt->execute();
    $customerResult = $customerStmt->get_result();

    // ...

    if ($customerResult->num_rows > 0) {
        $customerRow = $customerResult->fetch_assoc();
        $plainTextPasswordFromDatabase = $customerRow['Pass_word'];

        // Check if entered password matches the one stored in the database
        if ($enteredPassword === $plainTextPasswordFromDatabase) {
            $_SESSION['user_id'] = $customerRow['Cid'];
            // Successful login for a regular user
            header('Location: UserDashboard.php');
            exit();
        }
    } else {
        // Failed login, redirect back to the login page with an error message
        header('Location: index.php?error=true');
        exit();
    }
    // ...
} else {
    // Redirect back to the login page if the form was not submitted
    header('Location: index.php');
    exit();
}
