<?php
session_start();
include ('conn.php');

if(isset($_SESSION['user_id'])) {
    $_SESSION = array();
    session_destroy();
    header("Location: HomePage.php");
    exit();
} else {
    header("Location: index.php");
    exit();
}
?>
